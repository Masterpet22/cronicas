import { test, expect } from "@playwright/test";
import { bootPerformanceReference } from "./helpers/performance-harness.mjs";

async function sampleRendering(page) {
  await page.evaluate(() => {
    const game = window.__performanceReference.game;
    // Phaser también emite prerender en headlessStep, con renderer=null.
    window.__renderSample = { count: 0, callback: renderer => { if (renderer) window.__renderSample.count++; } };
    game.events.on("prerender", window.__renderSample.callback);
  });
  await page.waitForTimeout(950);
  return page.evaluate(() => {
    window.__performanceReference.game.events.off("prerender", window.__renderSample.callback);
    return window.__renderSample.count;
  });
}

test("rendimiento: la subida de nivel deja de dibujar escenas mientras espera", async ({ page }, info) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await bootPerformanceReference(page);
  await page.evaluate(async () => {
    const state = window.__performanceReference;
    const { LevelUpScene } = await import("/src/battle/scenes/level-up-scene.js?v=0.95.0");
    state.game.scene.add("level-up", LevelUpScene);
    const preview = structuredClone(state.scene.saveData);
    preview.progression.level++; preview.progression.attributePoints += 2;
    window.__levelPreview = state.scene.showPendingLevelUp(preview);
  });
  await expect(page.locator(".level-up-accessible")).toBeAttached({ timeout: 20000 });
  await expect.poll(() => page.evaluate(() => {
    const scene = window.__performanceReference.game.scene.getScene("level-up");
    return scene.children.getByName("level-up-panel")?.list.some(item => item.name === "level-up-continue" && item.input?.enabled);
  })).toBe(true);
  await page.waitForTimeout(2200);
  const renders = await sampleRendering(page);
  await info.attach("renderizado-subida", { body: JSON.stringify({ renders, milliseconds: 950 }), contentType: "application/json" });
  console.log(`Subida de nivel: ${renders} renders / 950 ms`);
  if (!process.env.TUTORIAL_BASELINE) expect(renders).toBeLessThanOrEqual(2);
  await page.keyboard.press("Enter");
  await expect.poll(() => page.evaluate(() => window.__performanceReference.scene.scene.isActive())).toBe(true);
  await page.evaluate(async () => { await window.__levelPreview; window.__performanceReference.game.destroy(true); });
});

test("rendimiento: la decisión del teniente conserva un fondo estático e interactivo", async ({ page }, info) => {
  await bootPerformanceReference(page);
  await page.evaluate(() => { window.__choice = window.__performanceReference.scene.playPrisonerChoice(); });
  await page.waitForTimeout(350);
  const renders = await sampleRendering(page);
  await info.attach("renderizado-decision", { body: JSON.stringify({ renders, milliseconds: 950 }), contentType: "application/json" });
  console.log(`Decisión del teniente: ${renders} renders / 950 ms`);
  if (!process.env.TUTORIAL_BASELINE) expect(renders).toBeLessThanOrEqual(2);
  const box = await page.locator("#game > canvas").boundingBox();
  await page.mouse.click(box.x + 330 / 960 * box.width, box.y + 350 / 540 * box.height);
  await page.evaluate(async () => { await window.__choice; });
  expect(await page.evaluate(() => window.__performanceReference.scene.saveData.campaign.banditPrisonerChoice)).toBe("interrogate");
  await page.evaluate(() => window.__performanceReference.game.destroy(true));
});
