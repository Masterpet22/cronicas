import { TUTORIAL_LESSON_IDS } from "../../src/content/sagas/futuro-prometedor/tutorial.js";

// Los escenarios ajenos a la formación parten de un jugador que ya la practicó.
// Los casos de currículo utilizan partidas nuevas y controles reales por separado.
export function learnedTutorialForTest(save) {
  save.campaign.sagaTutorial.completed = [...TUTORIAL_LESSON_IDS];
  return save;
}

export async function useLearnedTutorialSave(page, view = "headquarters") {
  await page.evaluate(async view => {
    const { loadSave, writeSave } = await import("/src/save.js?v=0.131.0");
    const { learnedTutorialForTest } = await import("/tests/helpers/saga-tutorial.mjs");
    const { battleRuntime } = await import("/src/battle/runtime.js?v=0.91.0");
    battleRuntime.activeSave = writeSave(learnedTutorialForTest(loadSave()));
    battleRuntime.releaseGameToMeta(view);
  }, view);
}
